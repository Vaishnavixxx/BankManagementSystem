package com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Customertbl")
public class Customer {
	@Id
	@Column(unique = true)
	private String adharno;
	@Column
	private String name;
	@Column
	private String address;
	@Column(unique = true)
	private String contact;
	@Column
	private String password;
	@Column
	private String accno;

	public String getAdharno() {
		return adharno;
	}

	public void setAdharno(String adharno) {
		this.adharno = adharno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	@Override
	public String toString() {
		return "Customer [adharno=" + adharno + ", name=" + name + ", address=" + address + ", contact=" + contact
				+ ", password=" + password + ", accno=" + accno + "]";
	}

	public Customer(String adharno, String name, String address, String contact, String password, String accno) {
		super();
		this.adharno = adharno;
		this.name = name;
		this.address = address;
		this.contact = contact;
		this.password = password;
		this.accno = accno;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

}
