package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.entity.Admin;
import com.entity.Customer;
import com.repository.AdminRepository;
import com.repository.CustomerRepository;
import com.service.AdminService;
import com.service.CustomerService;



@Controller
public class CustomerController {

	@Autowired
	private CustomerRepository customerRepo;
	
	@Autowired
	private CustomerService customerService;

	@GetMapping("/customerregister")
	public String openRegister(Model model) {
		model.addAttribute("customer" ,new Customer());
		return "customerregistration";
	}
	
	@GetMapping("/customerlogin")
	public String openLogin(Model model) {
		model.addAttribute("customer" ,new Customer());
		return "customerlogin";
	}
	
	@PostMapping("/customerregister")
	public String submitForm(@ModelAttribute("customer") Customer customer,Model model) {
		boolean result=customerService.registerCustmore(customer);
		
		if(result) {
			model.addAttribute("sucess","Customer's Account is Created...");
			return "customerlogin";
		}else {
			model.addAttribute("error" ,"Enter All Details...");
		}
		return "customerregistration";
	}
	
	@PostMapping("/customerlogin")
	public String submitLogin(@ModelAttribute("customer") Customer customer,Model model){
		Customer validcustomer=customerService.loginCustomer(customer.getAdharno() , customer.getPassword());
		if(validcustomer!=null) {
			model.addAttribute("modelName" , validcustomer.getAdharno());
			return "profile";
		}else {
			model.addAttribute("Error" ,"Username and password does not match");
		}
		return "customerlogin";
	}

}

