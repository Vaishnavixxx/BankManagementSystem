package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.entity.Admin;
import com.repository.AdminRepository;
import com.service.AdminService;

@Controller
public class AdminController {

	
	@Autowired
	AdminRepository adminRepo;
	
	@Autowired
	AdminService adminService;
	
	@GetMapping("/adminregsiter")
	public String adminRegister(Model model) {
		model.addAttribute("admin" ,new Admin());
		return "adminregister";
	}
	
	@GetMapping("/adminlogin")
	public String adminLogin(Model model) {
		model.addAttribute("admin" ,new Admin());
		return "adminlogin";
	}
	
	@PostMapping("/adminregsiter")
	public String submitAdmin(@ModelAttribute("admin") Admin admin,Model model) {
		boolean result=adminService.registerAdmin(admin);

		if(result) {
			model.addAttribute("sucess","New Employee Generated...");
			return "adminlogin";
		}else {
			model.addAttribute("error" ,"Faild to create");
		}
		return "adminregister";
	}
	
	@PostMapping("/adminlogin")
	public String loginAdmin(@ModelAttribute("admin") Admin admin,Model model) {
		Admin validAdmin = adminService.loginAdmin(admin.getAdminname(), admin.getPassword());
		if(validAdmin!=null) {
			model.addAttribute("modelName",validAdmin.getAdminname());
			return "profile";
		}else {
			model.addAttribute("Error","Username and password does not match");
		}
		return "adminregister";
	}
}
